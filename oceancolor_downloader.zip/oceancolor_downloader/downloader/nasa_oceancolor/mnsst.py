class Mnsst:
	def __init__(self, start_date, end_date, res, time_composite):
		pass

	def download(self, path):
		pass

	def __process(self):
		pass
