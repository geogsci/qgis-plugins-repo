PATH=$PATH:/Applications/QGIS.app/Contents/MacOS/bin
make
